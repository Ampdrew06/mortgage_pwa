import { useState } from "react";

function PMT(rate, nper, pv) {
  return (rate * pv) / (1 - Math.pow(1 + rate, -nper));
}

function NPER(rate, payment, pv) {
  return Math.log((payment / rate) / ((payment / rate) - pv)) / Math.log(1 + rate);
}

function App() {
  const [inputs, setInputs] = useState({
    loanAmount: 200000,
    loanTerm: 25,
    fixedRate: 4.5,
    fixedTerm: 3,
    followOnRate: 6.5,
    overpayment: 0,
    targetYears: ""
  });

  const updateInput = (key, value) => setInputs({ ...inputs, [key]: value });

  const {
    loanAmount,
    loanTerm,
    fixedRate,
    fixedTerm,
    followOnRate,
    overpayment,
    targetYears
  } = inputs;

  const fixedMonthlyRate = fixedRate / 100 / 12;
  const followOnMonthlyRate = followOnRate / 100 / 12;
  const fixedMonths = fixedTerm * 12;
  const totalMonths = loanTerm * 12;
  const paymentTermMonths = targetYears ? targetYears * 12 : fixedMonths;

  const monthlyPayment = loanAmount && PMT(fixedMonthlyRate, paymentTermMonths, -loanAmount) + (+overpayment || 0);

  let remainingBalance = "";
  if (loanAmount && (loanTerm - fixedTerm) > 0) {
    const compoundFactor = Math.pow(1 + fixedMonthlyRate, fixedMonths);
    const totalPaid = monthlyPayment * (compoundFactor - 1) / fixedMonthlyRate;
    remainingBalance = loanAmount * compoundFactor - totalPaid;
  }

  let secondaryPayment = "";
  if (loanAmount && (loanTerm - fixedTerm) > 0) {
    const remainingMonths = (loanTerm - fixedTerm) * 12;
    secondaryPayment = PMT(followOnMonthlyRate, remainingMonths, -remainingBalance);
  }

  let yearsRemaining = "";
  if (loanAmount) {
    if (targetYears && overpayment) {
      const n = NPER(fixedMonthlyRate, -monthlyPayment, loanAmount);
      yearsRemaining = n < 0 ? "N/A" : (n / 12).toFixed(2);
    } else if (targetYears) {
      yearsRemaining = targetYears;
    } else if (overpayment) {
      const basePayment = PMT(fixedMonthlyRate, totalMonths, -loanAmount);
      const n = NPER(fixedMonthlyRate, -(basePayment + (+overpayment)), loanAmount);
      yearsRemaining = (n / 12).toFixed(2);
    } else {
      yearsRemaining = loanTerm;
    }
  }

  return (
    <div className="App" style={{ padding: 20, maxWidth: 500, margin: 'auto' }}>
      <h1>Mortgage Calculator</h1>
      {["loanAmount", "loanTerm", "fixedRate", "fixedTerm", "followOnRate", "overpayment", "targetYears"].map(key => (
        <div key={key}>
          <label>{key.replace(/([A-Z])/g, ' $1')}:</label>
          <input type="number" value={inputs[key]} onChange={e => updateInput(key, e.target.value)} />
        </div>
      ))}
      <hr />
      <div><strong>Initial Fixed Monthly Payment:</strong> £{monthlyPayment.toFixed(2)}</div>
      <div><strong>Secondary Rate Payment:</strong> £{secondaryPayment ? secondaryPayment.toFixed(2) : ""}</div>
      <div><strong>Years Remaining:</strong> {yearsRemaining}</div>
      <div><strong>Remaining at Fixed Term End:</strong> £{remainingBalance ? remainingBalance.toFixed(2) : ""}</div>
    </div>
  );
}

export default App;
